import { createContext } from "react";

export const CartContext = createContext();

export const ProfileContext = createContext()